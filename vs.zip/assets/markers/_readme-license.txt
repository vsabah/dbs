The project "Map Icons Collection" was created by Nicolas Mollet under the Creative Commons Attribution-Share Alike 3.0 Unported license (CC BY SA 3.0 - http://creativecommons.org/licenses/by-sa/3.0/).

This license lets you remix, tweak, and build upon our work even for commercial reasons, as long as you credit the project and license your new creations under the identical terms.

Please credit: Maps Icons Collection https://mapicons.mapsmarker.com
Logo available at https://mapicons.mapsmarker.com/wp-content/uploads/2011/03/miclogo-88x31.gif

Some icons are derived from the project SJJB Map Icons (http://www.sjjb.co.uk/mapicons/) by SJJB Management (http://www.sjjb.co.uk/), licensed under Creative Commons Public Domain Dedication (http://creativecommons.org/licenses/publicdomain/).

Some icons are derived from the project User Interface Design Framework (http://www.webalys.com/design-interface-application-framework.php) by Webalys (http://www.webalys.com/).